---@diagnostic disable: lowercase-global
---@author: Lunatic Fox - Josélio Júnior <joseliojrx25@gmail.com>
---@copyright: Lunatic Fox - Josélio Júnior 2023
---@license: MIT

push = table.insert
remove = table.remove
join = table.concat
unpack = table.unpack or unpack

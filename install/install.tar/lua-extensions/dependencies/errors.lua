---@author: Lunatic Fox - Josélio Júnior <joseliojrx25@gmail.com>
---@copyright: Lunatic Fox - Josélio Júnior 2023
---@license: MIT

---@diagnostic disable-next-line: lowercase-global
function typeerror(msg)
  return '\n\n>\tTypeError: ' .. msg .. '\n'
end
